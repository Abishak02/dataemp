-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 13, 2023 at 02:08 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `employe_date`
--

CREATE TABLE `employe_date` (
  `id` int(11) NOT NULL,
  `name` varchar(250) DEFAULT NULL,
  `email` varchar(250) DEFAULT NULL,
  `phone` varchar(250) DEFAULT NULL,
  `gender` varchar(250) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `employe_date`
--

INSERT INTO `employe_date` (`id`, `name`, `email`, `phone`, `gender`, `status`) VALUES
(1, 'ajkhghj', 'jovialabishak@gmail.com', '4536546545', 'Male', 1),
(2, 'ajkhghj', 'jovialabishak@gmail.com', '4536546545', 'Male', 1),
(3, 'as', 'sas@gmail.com', '456464', 'Male', 1),
(4, 'ajkhghj', 'jovialabishak@gmail.com', '4536546545', 'Male', 1),
(5, 'as', 'sas@gmail.com', '456464', 'Male', 1),
(6, 'as', 'sas@gmail.com', '456464', 'Male', 1),
(7, 'as', 'sas@gmail.com', '456464', 'Male', 1),
(8, 'name', 'email', 'phone', 'gender', 0),
(9, 'as', 'sas@gmail.com', '456464', 'Male', 1),
(10, 'ajkhghj', 'jovialabishak@gmail.com', '4536546545', 'Male', 1),
(11, 'as', 'sas@gmail.com', '456464', 'Male', 1),
(12, 'as', 'sas@gmail.com', '456464', 'Male', 1),
(13, 'ajkhghj', 'jovialabishak@gmail.com', '4536546545', 'Male', 1),
(14, 'as', 'sas@gmail.com', '456464', 'Male', 1),
(15, 'as', 'sas@gmail.com', '456464', 'Male', 1),
(16, 'ajkhghj', 'jovialabishak@gmail.com', '4536546545', 'Male', 1),
(17, 'as', 'sas@gmail.com', '456464', 'Male', 1),
(18, 'as', 'sas@gmail.com', '456464', 'Male', 1),
(19, 'ajkhghj', 'jovialabishak@gmail.com', '4536546545', 'Male', 1),
(20, 'as', 'sas@gmail.com', '456464', 'Male', 1),
(21, 'as', 'sas@gmail.com', '456464', 'Male', 1),
(22, 'ajkhghj', 'jovialabishak@gmail.com', '4536546545', 'Male', 1),
(23, 'as', 'sas@gmail.com', '456464', 'Male', 1),
(24, 'as', 'sas@gmail.com', '456464', 'Male', 1),
(25, 'ajkhghj', 'jovialabishak@gmail.com', '4536546545', 'Male', 1),
(26, 'as', 'sas@gmail.com', '456464', 'Male', 1),
(27, 'as', 'sas@gmail.com', '456464', 'Male', 1),
(28, 'ajkhghj', 'jovialabishak@gmail.com', '4536546545', 'Male', 1),
(29, 'as', 'sas@gmail.com', '456464', 'Male', 1),
(30, 'as', 'sas@gmail.com', '456464', 'Male', 1),
(31, 'ajkhghj', 'jovialabishak@gmail.com', '4536546545', 'Male', 1),
(32, 'as', 'sas@gmail.com', '456464', 'Male', 1),
(33, 'as', 'sas@gmail.com', '456464', 'Male', 1),
(34, 'ajkhghj', 'jovialabishak@gmail.com', '4536546545', 'Male', 1),
(35, 'as', 'sas@gmail.com', '456464', 'Male', 1),
(36, 'as', 'sas@gmail.com', '456464', 'Male', 1),
(37, 'ajkhghj', 'jovialabishak@gmail.com', '4536546545', 'Male', 1),
(38, 'as', 'sas@gmail.com', '456464', 'Male', 1),
(39, 'as', 'sas@gmail.com', '456464', 'Male', 1),
(40, 'ajkhghj', 'jovialabishak@gmail.com', '4536546545', 'Male', 1),
(41, 'as', 'sas@gmail.com', '456464', 'Male', 1),
(42, 'as', 'sas@gmail.com', '456464', 'Male', 1),
(43, 'ajkhghj', 'jovialabishak@gmail.com', '4536546545', 'Male', 1),
(44, 'as', 'sas@gmail.com', '456464', 'Male', 1),
(45, 'as', 'sas@gmail.com', '456464', 'Male', 1),
(46, 'ajkhghj', 'jovialabishak@gmail.com', '4536546545', 'Male', 1),
(47, 'as', 'sas@gmail.com', '456464', 'Male', 1),
(48, 'as', 'sas@gmail.com', '456464', 'Male', 1),
(49, 'ajkhghj', 'jovialabishak@gmail.com', '4536546545', 'Male', 1),
(50, 'as', 'sas@gmail.com', '456464', 'Male', 1),
(51, 'as', 'sas@gmail.com', '456464', 'Male', 1),
(52, 'ajkhghj', 'jovialabishak@gmail.com', '4536546545', 'Male', 1),
(53, 'as', 'sas@gmail.com', '456464', 'Male', 1),
(54, 'as', 'sas@gmail.com', '456464', 'Male', 1),
(55, 'ajkhghj', 'jovialabishak@gmail.com', '4536546545', 'Male', 1),
(56, 'as', 'sas@gmail.com', '456464', 'Male', 1),
(57, 'as', 'sas@gmail.com', '456464', 'Male', 1),
(58, 'ajkhghj', 'jovialabishak@gmail.com', '4536546545', 'Male', 1),
(59, 'as', 'sas@gmail.com', '456464', 'Male', 1),
(60, 'as', 'sas@gmail.com', '456464', 'Male', 1),
(61, '', '', '', '', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `employe_date`
--
ALTER TABLE `employe_date`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `employe_date`
--
ALTER TABLE `employe_date`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
